from unicodedata import name
from django.urls import path

from langeum.endpoint.models import Devices
from .views import ListCategory

urlpatterns = [
    path('Devices', ListCategory.as_view(), name ='Devices'),
    path('Devices/'),

]