# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

# Gerätedaten einens eingeloggten Nutzers

class Devices(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    device_type = models.CharField(max_length=500)
    device_id = models.CharField(max_length=500)
    device_token = models.CharField(max_length=500)
    created_at = models.DateTimeField()

    class Meta:
        db_table = 'devices'

# Nutzer (Unternehmen und Kunden)

class Users(models.Model):
    user_id = models.CharField(max_length=500)
    email = models.CharField(max_length=500)
    password = models.CharField(max_length=500)
    name = models.CharField(max_length=20)
    is_company = models.BooleanField()
    is_mail_verified = models.BooleanField()
    email_verification_code = models.CharField(max_length=500)
    gender = models.CharField(max_length=20, blank=True, null=True)
    birth_date = models.DateTimeField()
    is_active = models.BooleanField()
    is_reported = models.BooleanField()
    is_blocked = models.BooleanField()
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

    class Meta:
        db_table = 'users'

# Sicherheitswarnungen

class UserSecurityIssues(models.Model):
    item_id = models.DateTimeField()
    user_id = models.DateTimeField()
    type = models.DateTimeField()
    description = models.DateTimeField()
    created_at = models.DateTimeField()

# Kategorien, die Kunden gefallen

class UserProductCategories(models.Model):
    user_id = models.CharField(max_length=500)
    product_category = models.CharField(max_length=500)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()

    class Meta:
        db_table = 'user_product_categories'

# Nutzereinstellungen

class UserSettings(models.Model):
    user_id = models.CharField(max_length=500)
    company_notifications = models.BooleanField()
    post_notifications = models.BooleanField()
    product_notifications = models.BooleanField()
    comment_likes_notifications = models.BooleanField()
    direct_message_notifications = models.BooleanField()
    company_emails = models.BooleanField()
    app_language = models.CharField(max_length=500)

class UserPreferredLanguages(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    language_name = models.CharField(max_length=500)

# Kommentare für alle Dienste auf der Plattform

class Comments(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    text = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'comments'

# Likes und Dislikes auf Kommentare

class CommentReactions(models.Model):
    item_id = models.TextField()
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    comment_id = models.CharField(max_length=500)
    is_plus_reaction = models.BooleanField()
    created_at = models.DateTimeField()

    class Meta:
        db_table = 'comment_reactions'

# Antworten auf Kommentare

class CommentReplies(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    text = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

# Unternehmensprofile

class Companies(models.Model):
    user_id = models.CharField(max_length=500)
    employees = models.IntegerField()
    name = models.CharField(max_length=20, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    description = models.CharField(max_length=8000, blank=True, null=True)
    slogan = models.CharField(max_length=500, blank=True, null=True)
    company_age = models.DateTimeField(blank=True, null=True)
    plan = models.IntegerField()
    profile_picture = models.CharField(max_length=500, blank=True, null=True)
    profile_banner = models.CharField(max_length=500, blank=True, null=True)
    sector = models.CharField(max_length=20, blank=True, null=True)
    organizational_type = models.CharField(max_length=20, blank=True, null=True)
    keywords = models.CharField(max_length=500, blank=True, null=True)
    langeum_link = models.CharField(max_length=500)
    contact_mail = models.CharField(max_length=500)
    impressum = models.CharField(max_length=500)
    phone = models.CharField(max_length=500)
    tiktok_name = models.CharField(max_length=500)
    pinterest_name = models.CharField(max_length=500)
    instagram_name = models.CharField(max_length=500)
    tags = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'companies'

# Öffnungszeiten des Unternehmens

class CompanyOpeningHours(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    day = models.CharField(max_length=500)
    start_time = models.CharField(max_length=500)
    end_time = models.CharField(max_length=500)

# Standorte des Unternehmens

class CompanyLocations(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    street = models.CharField(max_length=20, blank=True, null=True)
    street_code = models.IntegerField(blank=True, null=True)
    zip_code = models.IntegerField(blank=True, null=True)
    city = models.CharField(max_length=20, blank=True, null=True)
    state = models.CharField(max_length=20, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)

# Spezialgebiete eines Unternehmens

class CompanySpecialities(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    speciality_name = models.CharField(max_length=500)

# Buttons der Unternehmensprofile (Website besuchen, Mehr erfahren, ...)

class CompanyButtons(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    text = models.CharField(max_length=20)
    link = models.CharField(max_length=500)
    date = models.DateTimeField()

    class Meta:
        db_table = 'company_buttons'

# Standorte der Unternehmen mit Adressdaten

class CompanyLocations(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    street = models.CharField(max_length=20, blank=True, null=True)
    street_code = models.IntegerField(blank=True, null=True)
    zip_code = models.IntegerField(blank=True, null=True)
    city = models.CharField(max_length=20, blank=True, null=True)
    state = models.CharField(max_length=20, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        db_table = 'company_locations'

# Sternebewertung oder Rezension auf ein Unternehmen

class CompanyRatings(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    text = models.CharField(max_length=500, blank=True, null=True)
    rating = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'company_ratings'

# Verschiedene Unternehmens-Kategorien, welche auf der Explore-Page personalisiert dem Nutzer angezeigt werden

class CompanyCategories(models.Model):
    item_id = models.CharField(max_length=500)
    name = models.CharField(max_length=500)
    type = models.CharField(max_length=500)

# Nachrichten in Chats mit Unternehmen

class ConversationMessages(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    attachment = models.CharField(max_length=500, blank=True, null=True)
    attachment_file_type = models.CharField(db_column='attachmentFileType', max_length=20, blank=True, null=True)  # Field name made lowercase.
    text = models.CharField(max_length=500)
    sent_message = models.BooleanField()
    received_message = models.BooleanField()
    opened_message = models.BooleanField()
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'conversation_messages'

# Chats mit Unternehmen

class Conversations(models.Model):
    item_id = models.CharField(max_length=500)
    latest_message = models.CharField(max_length=500, blank=True, null=True)
    latest_message_sent_by = models.CharField(max_length=500, blank=True, null=True)
    latest_message_sent_by_username = models.CharField(max_length=500, blank=True, null=True)
    latest_message_sent_time = models.DateTimeField(blank=True, null=True)
    latest_message_read = models.IntegerField()
    muted = models.BooleanField()
    customer_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'conversations'

# Unternehmen, die von Kunden gefolgt werden (Verbindungen) 

class CustomerRelations(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    created_at = models.DateTimeField()
    feed_notifications = models.BooleanField()
    push_notifications = models.BooleanField()
    mail_notifications = models.BooleanField()

    class Meta:
        db_table = 'customer_relations'

# Neuigkeiten & Tipps für besseres Social-Media-Management, die Unternehmen über die Dashboard-Funktion erhalten

class News(models.Model):
    item_id = models.CharField(max_length=500)
    text = models.CharField(max_length=500, blank=True, null=True)
    image = models.CharField(max_length=500, blank=True, null=True)
    video = models.CharField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField()

    class Meta:
        db_table = 'news'

# Neuigkeiten, die Kunden über die Unternehmen erhalten, denen sie folgen

class Notifications(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    text = models.CharField(max_length=8000)
    date = models.DateTimeField()

    class Meta:
        db_table = 'notifications'

# Push-Nachichten für Mobile Devices

class PushNotifications(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    title = models.CharField(max_length=50)
    text = models.CharField(max_length=8000)
    date = models.DateTimeField()
    profile_picture = models.CharField(max_length=500)
    custom_image = models.CharField(max_length=500)

# Email Nachrichten, die an Kunden geschickt werden

class EmailNotifications(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    subject = models.CharField(max_length=998)
    company_icon = models.CharField(max_length=500)
    company_banner = models.CharField(max_length=500)

# Angehängte Dateien für Email Nachrichten

class EmailNotificationFiles(models.Model):
    item_id = models.CharField(max_length=500)
    email_id = models.CharField(max_length=500)
    file_item = models.CharField(max_length=500)

# Buttons, die zur Email hinzugefügt wurden

class EmailNotificationButtons(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    text = models.CharField(max_length=20)
    link = models.CharField(max_length=500)
    date = models.DateTimeField()

# Punkte, die Kunden bei einem bestimmten Unternehmen gesammelt haben

class Points(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    amount = models.IntegerField()

    class Meta:
        db_table = 'points'


# Vergangene Aktionen, bei denen ein Kunde Punkte haben

class PointsHistory(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    amount = models.IntegerField()
    reason = models.CharField(max_length=8000)
    created_at = models.DateTimeField()
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'points_history'

# Treueprodukte, die ein Unternehmen anbietet

class PointsProducts(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    shop_id = models.CharField(max_length=500)
    name = models.CharField(max_length=500, blank=True, null=True)
    video = models.CharField(max_length=500, blank=True, null=True)
    product_category = models.BooleanField()
    points = models.IntegerField(blank=True, null=True)
    sector = models.CharField(max_length=500, blank=True, null=True)
    link_to_shop_item = models.CharField(max_length=500)
    expiration_date = models.DateTimeField()
  
# Bilder eines Treueprodukts       

class PointsProductsImages(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    image = models.CharField(max_length=500)

# Anfragen eines Treueprodukts

class PointsUserRequest(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    product_id = models.CharField(max_length=500)
    is_coupon = models.BooleanField()
    street = models.CharField(max_length=500, blank=True, null=True)
    street_number = models.IntegerField(blank=True, null=True)
    zip_code = models.CharField(max_length=500, blank=True, null=True)
    state = models.CharField(max_length=500, blank=True, null=True)
    phone_number = models.CharField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField()

# Beiträge

class Posts(models.Model):
    content_id = models.CharField(max_length=500, blank=True, null=True)
    user_id = models.CharField(max_length=500)
    image = models.CharField(max_length=500, blank=True, null=True)
    video = models.CharField(max_length=500, blank=True, null=True)
    contains_poll = models.BooleanField()
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'posts'

# Optionen eines Beitrags mit einer Abstimmung

class PostPollOptions(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500, blank=True, null=True)
    option_text = models.CharField(max_length=20)

    class Meta:
        db_table = 'post_poll_options'

# Antworten auf einen Beitrag mit einer Abstimmung

class PostPollResponses(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    option_id = models.IntegerField()
    created_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'post_poll_responses'

# Beiträge, an denen Kunden nicht interessiert sind

class PostNotInterest(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Beiträge, die sich ein Nutzer angesehen hat

class PostHistory(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Termine eines Unternehmens

class Appointments(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    date = models.DateTimeField(blank=True, null=True)
    type = models.CharField(max_length=500)
    public = models.CharField(max_length=500)
    description = models.CharField(max_length=5000)
    more_information = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

# Teilnehmer eines Termines (Event)

class AppointmentParticipants(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Reaktionen auf einen Termin

class AppointmentReactions(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Produkte von Unternehmen

class Products(models.Model):
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    shop_id = models.CharField(max_length=500)
    name = models.CharField(max_length=500, blank=True, null=True)
    video = models.CharField(max_length=500, blank=True, null=True)
    product_category = models.BooleanField()
    price = models.IntegerField(blank=True, null=True)
    sector = models.CharField(max_length=500, blank=True, null=True)
    link_to_shop_item = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        db_table = 'products'

# Produktbilder der Produkte von Unternehmen

class ProductImages(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    image = models.CharField(max_length=500)

    class Meta:
        db_table = 'product_images'

# Kategorien eines Unternehmensshops

class ProductCategories(models.Model):
    item_id = models.CharField(max_length=500)
    name = models.CharField(max_length=500)
    description = models.CharField(max_length=500)
    banner = models.CharField(max_length=500)

# Produkte in einer Kategorie

class ProductCategoryItems(models.Model):
    item_id = models.CharField(max_length=500)
    product_id = models.CharField(max_length=500)

# Reaktionen auf Produkte

class ProductReactions(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField()

# Produkte, an denen Kunden nicht interessiert sind

class PostNotInterest(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Reaktionen auf Beiträge

class Reactions(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    is_plus_reaction = models.BooleanField()
    created_at = models.DateTimeField()

    class Meta:
        db_table = 'reactions'

# Update-Beiträge (Story-Funktion)

class Updates(models.Model):
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    file_url = models.CharField(max_length=500)
    is_image = models.BooleanField()
    thumbnail_url = models.CharField(max_length=500)
    title = models.CharField(max_length=20)
    description = models.CharField(max_length=500)
    see_more = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'updates'

# Bewertungen für Updates

class UpdateRatings(models.Model):
    item_id = models.CharField(max_length=500)
    content_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField()

# Unternehmen, die von Kunden gemeldet wurden

class CompanyReports(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    reason = models.CharField(max_length=5000)
    created_at = models.DateTimeField(blank=True, null=True)

# Nutzer (aus z.B. Kommentare) die von anderen Nutzern gemeldet wurden

class UserReports(models.Model):
    item_id = models.CharField(max_length=500)
    reported_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    reason = models.CharField(max_length=5000)
    created_at = models.DateTimeField(blank=True, null=True)

# Kunden, die Unternehmen blockiert haben

class BlockedCompanies(models.Model):
    item_id = models.CharField(max_length=500)
    company_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Nutzer, die andere Nutzer gemeldet haben

class BlockedUsers(models.Model):
    item_id = models.CharField(max_length=500)
    blocked_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)

# Log Table, in der alle Aktivitäten (Interaktionen mit Backend) eines Nutzers gespeichert werden

class EventLogs(models.Model):
    item_id = models.CharField(max_length=500)
    user_id = models.CharField(max_length=500)
    device_id = models.CharField(max_length=500)
    activity = models.CharField(max_length=500)
    created_at = models.DateTimeField(blank=True, null=True)
    edited_at = models.DateTimeField(blank=True, null=True)

