from django.contrib import admin

from .models import Devices

admin.site.register(Devices)
