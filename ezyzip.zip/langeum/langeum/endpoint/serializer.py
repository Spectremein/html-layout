from dataclasses import fields
from rest_framework import serializers
from .models import Devices


class devicesserializer(serializers.ModelSerializer):

    class Meta:
        fields = (
            'item_id'
            'user_id'
            'device_type'
            'device_id'
            'device_token'
            'created_at'
        )
        model = Devices