from unicodedata import category
from django.shortcuts import render
from rest_framework import generics

from langeum.endpoint.models import Devices
from .models import Devices
from .serializer import devicesserializer

class ListCategory(generics.ListcreateAPIView):
    queryset = Devices.objects.all
    serializer_class = devicesserializer

